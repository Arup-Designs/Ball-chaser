let c = document.getElementById("c");
let middleText = document.getElementById("middleText")
let timerText = document.getElementById("timerText")
let retryContainer = document.getElementById("retryContainer")
let retryBtn = document.getElementById("retryBtn")
let finalScoreText = document.getElementById("finalScore")
let highestScore = document.getElementById("highestScore")
let lowerText = document.getElementById("lowerTxt")
c.height = window.innerHeight;
c.width = window.innerWidth;
let ctx = c.getContext("2d");

const joystick = nipplejs.create({
  zone: document.getElementById("joystickContainer"),
  mode: "dynamic",
  color: "rgba(255,255,255,1)",
  size: 140
});

//HELPER FUNCTIONS
function dist(x1, y1, x2, y2) {
  let dx = x2 - x1;
  let dy = y2 - y1;
  return Math.sqrt(dx * dx + dy * dy);
}
function randInt(min, max) {
 min = Math.ceil(min);
 max = Math.floor(max);
 return Math.floor(Math.random() * (max - min + 1) + min);
}
//BALL SETUP
function Ball({position,velocity,color}){
  this.position = position;
  this.velocity = velocity||{x:0,y:0};
  this.radius = 10;
  this.color = color || "red"
  this.draw = function(){
    ctx.beginPath();
    ctx.fillStyle = color
    ctx.arc(this.position.x,this.position.y,this.radius,0,2*Math.PI)
    ctx.fill();
  }
  this.move = function() {
  this.position.x += this.velocity.x;
  this.position.y += this.velocity.y;
  
  //X axis
  if (this.position.x - this.radius < 0) {
    this.position.x = this.radius; // reset to inside
    this.velocity.x = -this.velocity.x;
  } else if (this.position.x + this.radius > window.innerWidth) {
    this.position.x = window.innerWidth - this.radius;
    this.velocity.x = -this.velocity.x;
  }
  
  //Y axis
  if (this.position.y - this.radius < 0) {
    this.position.y = this.radius;
    this.velocity.y = -this.velocity.y;
  } else if (this.position.y + this.radius > window.innerHeight) {
    this.position.y = window.innerHeight - this.radius;
    this.velocity.y = -this.velocity.y;
  }
  }
}

let balls = [];
let ballSpeed = 2;
let colors = ["red","#1E90FF","#FFFF00","cyan","#FF0099","#00FF85","#800080","#FFA500","#FF00FF","#FFFFFF"]
let timer = [0,0,0,0]
let waveCounter = 1;
let waveDelay = 100;
let playerSpeed = 4;
let startTime = null;
let savedScore=0;
let isGamePause = false;

savedScore = JSON.parse(localStorage.getItem("score"))

//amt = amount 
for(let amt=0;amt<=1;amt++){
  balls.push(new Ball({position:{x:randInt(0,window.innerWidth),y:randInt(0,window.innerHeight)},velocity:{x:randInt(-ballSpeed,ballSpeed),y:randInt(-ballSpeed,ballSpeed)},color:colors[randInt(0,colors.length-1)]}))
}

//PLAYER SETUP
function Player({velocity,position}){
  this.position = position;
  this.velocity = velocity||{x:0,y:0};
  this.size = 30;
  this.angle = 0;
  this.color = "rgba(248, 200, 220,1)"
  this.draw = function() {
    ctx.save();
    ctx.translate(this.position.x+this.size/2,
                  this.position.y+this.size/2
    )
    ctx.rotate(this.angle)
    ctx.fillStyle = this.color;
    ctx.fillRect(-this.size/2,-this.size/2,this.size,this.size);
    
    ctx.restore();
  }
  this.move = function(){
    this.position.x += this.velocity.x;
    this.position.y += this.velocity.y;
    if(this.position.x <=0){
      this.position.x = 0;
    }
    if(this.position.x+this.size >= window.innerWidth){
      this.position.x=window.innerWidth-this.size
    }
    if(this.position.y <=0){
      this.position.y = 0;
    }
    if(this.position.y+this.size >= window.innerHeight){
      this.position.y=window.innerHeight-this.size
    }
    
  }
}

let player = new Player({position:{x:100,y:100}})

//JOYSTICK
function joystickSetup(){
  joystick.on("start",function(evt){
    lowerText.style.opacity = "0";
    document.documentElement.requestFullscreen();
   /* c.height = window.innerHeight;
    c.width = window.innerWidth;*/

  })
joystick.on('move', function(evt,data){
    player.velocity.x = data.vector.x*playerSpeed;
    player.velocity.y = -data.vector.y*playerSpeed;
    player.angle = Math.atan2(data.vector.x,data.vector.y)
    
  })
joystick.on('end', function() {
  player.velocity.x = 0;
  player.velocity.y = 0;
  });
}
joystickSetup();
  
//COLLISION FUNCTIONS
function isCircleCollided(balls) {
  for (let i = 0; i < balls.length; i++) {
    for (let j = i + 1; j < balls.length; j++) {
      const obj1 = balls[i];
      const obj2 = balls[j];
      
      const dx = obj1.position.x - obj2.position.x;
      const dy = obj1.position.y - obj2.position.y;
      const distance = Math.hypot(dx, dy);
      
      if (distance <= obj1.radius + obj2.radius) {
        return true;
      }
    }
  }
  return false;
}
function resolveBallCollisions(balls) {
  for (let i = 0; i < balls.length; i++) {
    for (let j = i + 1; j < balls.length; j++) {
      const ball1 = balls[i];
      const ball2 = balls[j];
      
      const xDist = ball2.position.x - ball1.position.x;
      const yDist = ball2.position.y - ball1.position.y;
      const distance = Math.hypot(xDist, yDist);
      const minDist = ball1.radius + ball2.radius;
      
      if (distance < minDist) {
        const xVelocityDiff = ball1.velocity.x - ball2.velocity.x;
        const yVelocityDiff = ball1.velocity.y - ball2.velocity.y;
        
        if (xVelocityDiff * xDist + yVelocityDiff * yDist >= 0) {
          const angle = Math.atan2(yDist, xDist);
          
          // Get speeds (magnitudes) before collision
          const speed1 = Math.hypot(ball1.velocity.x, ball1.velocity.y);
          const speed2 = Math.hypot(ball2.velocity.x, ball2.velocity.y);
          
          // Rotate original velocities
          const dir1 = {
            x: ball1.velocity.x * Math.cos(angle) + ball1.velocity.y * Math.sin(angle),
            y: -ball1.velocity.x * Math.sin(angle) + ball1.velocity.y * Math.cos(angle)
          };
          const dir2 = {
            x: ball2.velocity.x * Math.cos(angle) + ball2.velocity.y * Math.sin(angle),
            y: -ball2.velocity.x * Math.sin(angle) + ball2.velocity.y * Math.cos(angle)
          };
          
          // Swap x directions (along collision axis), keep y (perpendicular) the same
          const newDir1 = { x: dir2.x, y: dir1.y };
          const newDir2 = { x: dir1.x, y: dir2.y };
          
          // Rotate back
          const finalV1 = {
            x: newDir1.x * Math.cos(-angle) + newDir1.y * Math.sin(-angle),
            y: -newDir1.x * Math.sin(-angle) + newDir1.y * Math.cos(-angle)
          };
          const finalV2 = {
            x: newDir2.x * Math.cos(-angle) + newDir2.y * Math.sin(-angle),
            y: -newDir2.x * Math.sin(-angle) + newDir2.y * Math.cos(-angle)
          };
          
          // Normalize and scale to original speed
          const normalize = (v, speed) => {
            const mag = Math.hypot(v.x, v.y);
            return {
              x: (v.x / mag) * speed,
              y: (v.y / mag) * speed
            };
          };
          
          const adjustedV1 = normalize(finalV1, speed1);
          const adjustedV2 = normalize(finalV2, speed2);
          
          ball1.velocity.x = adjustedV1.x;
          ball1.velocity.y = adjustedV1.y;
          ball2.velocity.x = adjustedV2.x;
          ball2.velocity.y = adjustedV2.y;
        }
      }
    }
  }
}
function isBallCollidingWithPlayer(ball, player) {
  // Translate ball to origin based on player center
  const cx = ball.position.x - (player.position.x + player.size / 2);
  const cy = ball.position.y - (player.position.y + player.size / 2);

  // Rotate ball in opposite direction of player (un-rotate)
  const sin = Math.sin(-player.angle);
  const cos = Math.cos(-player.angle);
  const rx = cx * cos - cy * sin;
  const ry = cx * sin + cy * cos;

  // Find the closest point on the axis-aligned square to the unrotated circle center
  const halfSize = player.size / 2;
  const closestX = Math.max(-halfSize, Math.min(rx, halfSize));
  const closestY = Math.max(-halfSize, Math.min(ry, halfSize));

  // Distance between circle center and closest point
  const dx = rx - closestX;
  const dy = ry - closestY;

  return dx * dx + dy * dy <= ball.radius * ball.radius;
}

//BUTTONS
retryBtn.onclick = function(){
  location.reload(true)
}

//UPDATE LOOP
function animate(ct){
  if(isGamePause) return;
  ctx.fillStyle = "rgba(0,0,0,0.1)"
  ctx.fillRect(0,0,window.innerWidth, window.innerHeight)
  
  
  timer[0] += 0.1;
  if(!startTime)startTime = ct
  const elapsedMs = ct - startTime;
  const seconds = Math.floor(elapsedMs/1000);
  timerText.innerHTML = "survived for<br>" + seconds;
  
  
  player.draw();
  player.move();
  //texts
  if(timer[0] >= 5){
    middleText.textContent = "wave "+waveCounter
    middleText.style.opacity = 1;
    if(timer[0]>=10){
    middleText.style.opacity = 0;
    if(timer[0] >= waveDelay){
    timer[0] = 0;
    waveCounter+=1;
    for(let i = 0;i<=waveCounter;i++){
     balls.push(new Ball({position:{x:randInt(0,window.innerWidth),y:randInt(0,window.innerHeight)},velocity:{x:randInt(-ballSpeed,ballSpeed),y:randInt(-ballSpeed,ballSpeed)},color:colors[randInt(0,colors.length-1)]}))
    }
      
    }
    }
    
    
  }
  
  
  for(let i = 0;i <=balls.length-1;i++){
    let bl = balls[i];
    bl.draw();
    bl.move();
    if(isBallCollidingWithPlayer(bl,player)){
      if(seconds>savedScore){
        localStorage.setItem("score",JSON.stringify(seconds))
        savedScore = JSON.parse(localStorage.getItem("score"))
      }
      isGamePause= true;
      retryContainer.style.display="block";
      finalScoreText.innerHTML = "you survived for<br>"+seconds+"<br>seconds";
      highestScore.innerHTML = "longest time<br>"+savedScore
    }
  }
  
   if(isCircleCollided(balls)){
   resolveBallCollisions(balls)
   //balls.push(new Ball({position:{x:randInt(0,window.innerWidth),y:randInt(0,window.innerHeight)},velocity:{x:randInt(-5,5),y:randInt(-5,5)},color:colors[randInt(0,colors.length-1)]}))
  }
  
  requestAnimationFrame(animate);
}
animate();